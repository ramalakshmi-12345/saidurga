import React, { useState } from 'react';

function ToggleButton() {
  const [isOn, setIsOn] = useState(false);
  const [toggleCount, setToggleCount] = useState(0);

  const handleClick = () => {
    setIsOn((prevIsOn) => !prevIsOn);
    setToggleCount((prevToggleCount) => prevToggleCount + 1);
  };

  return (
    <div>
      <button
        style={{
          backgroundColor: isOn ? 'blue' : 'purple',
          color: 'white',
          padding: '10px 20px',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
        }}
        onClick={handleClick}
      >
        {isOn ? 'ON' : 'OFF'}
      </button>
      <p>Toggled {toggleCount} times</p>
    </div>
  );
}

export default ToggleButton;