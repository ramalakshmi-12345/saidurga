import React, { useState, useMemo } from 'react';

function FactorialComponent() {
  const [number, setNumber] = useState(1);

  const factorial = useMemo(() => {
    if (number < 0) {
      return 'Factorial is not defined for negative numbers';
    } else if (number === 0 || number === 1) {
      return 1;
    } else {
      let result = 1;
      for (let i = 2; i <= number; i++) {
        result *= i;
      }
      return result;
    }
  }, [number]);

  return (
    <div>
      <h1>Factorial Calculator</h1>
      <input
        type="number"
        value={number}
        onChange={(e) => setNumber(parseInt(e.target.value))}
      />
      <p>Factorial: {factorial}</p>
    </div>
  );
}

export default FactorialComponent;