import React, { useState, useEffect, useMemo } from 'react';

function CategoryData() {
  
  const [category, setCategory] = useState('all');
  const [data, setData] = useState([]);
category changes
  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch(`("https://fakestoreapi.com/products"));
      const jsonData = await response.json();
      setData(jsonData);
    };
    fetchData();
  }, [category]);

  
    return data;
  }, [data]);

  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
  };

  return (
    <div>
      <select value={category} onChange={handleCategoryChange}>
        <option value="all">All</option>
        <option value="category1">Category 1</option>
        <option value="category2">Category 2</option>
      </select>
      <ul>
        {memoizedData.map((item) => (
          <li key={("https://fakestoreapi.com/products")}>{item.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default CategoryData;
