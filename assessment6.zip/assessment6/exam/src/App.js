
import './App.css';
import Button from './components/Button';
import Factorial from './components/Factorial';
import Toggle from './components/Toggle';
function App() {
  return (
    <div className="App">
      <Button/>
      <hr></hr>
      <Factorial/>
      <hr></hr>
      <Toggle/>
    </div>
  );
}

export default App;
