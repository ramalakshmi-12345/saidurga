
import './App.css';
import Validation from './components/Validation';
import Pagination from './components/Pagination';
import Api2 from './components/Api2';
import Image from './components/Image';
import Api from './components/Api';
function App() {
  return (
    <div className="App">
      <Api2/>
      <Validation/>
      <Api/>
      <Image/>
      
      <PaginationContextProvider>
          <PaginationChange></PaginationChange>

        </PaginationContextProvider>
    </div>
  );
}

export default App;
