import React, { useState, useEffect, useMemo } from 'react';

function Products() {
  const [category, setCategory] = useState('');
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetch(("https://fakestoreapi.com/products"))
      .then(response => response.json())
      .then(data => setCategories(data));
  }, []);

  useEffect(() => {
    if (!category) return ;
    fetch(("https://fakestoreapi.com/products"))
      .then(response => response.json())
      .then(data => setProducts(data));
  }, [category]);

  const memoizedProducts = useMemo(() => products, [products]);

  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
  };

  return (
    <div>
      <select value={category} onChange={handleCategoryChange}>
        <option value="">Select a category</option>
        {categories.map(category => (
          <option key={category} value={category}>{category}</option>
        ))}
      </select>
      <ul>
        {memoizedProducts.map(product => (
          <li key={("https://fakestoreapi.com/products")}>
            <h2>{product.title}</h2>
            <h2>{product.description}</h2>
            <h2>{product.price}</h2>
          </li>
        ))}
      </ul>
 </div>
);
}
export default Products;