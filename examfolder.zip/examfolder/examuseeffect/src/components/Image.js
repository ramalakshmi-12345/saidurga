
import React, { useState, useEffect } from 'react';

const images = [
  '<img src=downloads.img30>',
  '<img src=downloads.img31>',
  '<img src=downloads.img32>',
  '<img src=downloads.img33>',
  '<img src=downloads.img34>'
];
const ImageCarousel = () => {
    const [currentIndex, setCurrentIndex] = useState(0);
  
    useEffect(() => {
      const timer = setInterval(() => {
        setCurrentIndex((currentIndex + 1) % images.length);
      }, 5000);
  
      return () => clearInterval(timer);
    }, [currentIndex, images.length]);
  
    return (
      <div>
        <img src={images[currentIndex]} alt={`Image ${currentIndex + 1}`} />
      </div>
    );
  };
  
  export default ImageCarousel;