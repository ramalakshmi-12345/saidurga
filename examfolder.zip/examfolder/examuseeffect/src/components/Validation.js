import React, { useState, useEffect } from "react";

const FormWithValidation = () => {
  const [formData, setFormData] = useState({ name: "", email: "" });
  const [isValid, setIsValid] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  useEffect(() => {
    const isNameValid = formData.name.trim() !== "";
    const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email);
    setIsValid(isNameValid && isEmailValid);
  }, [formData]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isValid) alert("Form Submitted!");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" onChange={handleChange} placeholder="Name" />
      <input name="email" onChange={handleChange} placeholder="Email" />
      <button type="submit" disabled={!isValid}>Submit</button>
    </form>
  );
};

export default FormWithValidation;